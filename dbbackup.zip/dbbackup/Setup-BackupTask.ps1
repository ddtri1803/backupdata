# Setup-BackupTask.ps1 #
# Định nghĩa các biến
$taskName = Automated Database Backup
$scriptPath = EProgramsxamppdbbackupbackup_script.ps1  # Đường dẫn đến tệp sao lưu của bạn
$taskDescription = Runs a PowerShell script to backup the database every 10 minutes.

# Xóa tác vụ nếu đã tồn tại
Unregister-ScheduledTask -TaskName $taskName -Confirm$false -ErrorAction SilentlyContinue

# Tạo trigger (kích hoạt) để chạy mỗi 10 phút
$trigger = New-ScheduledTaskTrigger -Daily -At 0000 # Bắt đầu từ 0000
$trigger.RepetitionInterval = [System.TimeSpan]FromMinutes(10)  # Lặp lại mỗi 10 phút
$trigger.RepetitionDuration = [System.TimeSpan]FromDays(1)  # Lặp lại trong suốt 1 ngày

# Tạo action (hành động) để chạy kịch bản sao lưu
$action = New-ScheduledTaskAction -Execute powershell.exe -Argument -File `$scriptPath`

# Tạo điều kiện và cài đặt (cấu hình)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

# Tạo tài khoản người dùng nếu cần (thay đổi tài khoản nếu cần thiết)
$principal = New-ScheduledTaskPrincipal -UserId SYSTEM -LogonType ServiceAccount

# Tạo tác vụ
Register-ScheduledTask -TaskName $taskName -Description $taskDescription -Trigger $trigger -Action $action -Settings $settings -Principal $principal
