# Định nghĩa các biến
$date = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = "E:\Programs\xampp\dbbackup\data"  # Thư mục sao lưu
$mysqlDir = "E:\Programs\xampp\mysql\bin"  # Thư mục cài đặt MySQL
$dbUser = "your_db_user"  # Tài khoản người dùng cơ sở dữ liệu
$dbPass = "your_db_password"  # Mật khẩu cơ sở dữ liệu
$logFile = "$backupDir\backup_log.txt"  # Tệp ghi log
$emailTo = "recipient@example.com"  # Địa chỉ email người nhận
$emailFrom = "sender@example.com"  # Địa chỉ email người gửi
$smtpServer = "smtp.example.com"  # Máy chủ SMTP
$smtpPort = 587  # Cổng SMTP
$smtpUser = "smtp_user"  # Tài khoản SMTP
$smtpPass = "smtp_password"  # Mật khẩu SMTP

# Tạo thư mục sao lưu nếu chưa tồn tại
if (-not (Test-Path -Path $backupDir)) {
    New-Item -ItemType Directory -Path $backupDir
}

# Ghi log bắt đầu sao lưu
Write-Output "Starting backup: $(Get-Date)" | Out-File -FilePath $logFile -Append

# Lấy danh sách các cơ sở dữ liệu
try {
    $databases = & "$mysqlDir\mysql.exe" -u $dbUser -p$dbPass -e "SHOW DATABASES;" | Select-Object -Skip 1
} catch {
    Write-Output "Failed to list databases: $(Get-Date) - $_" | Out-File -FilePath $logFile -Append
    exit 1
}

# Danh sách cơ sở dữ liệu hệ thống cần loại trừ
$systemDatabases = @("information_schema", "performance_schema", "mysql", "sys")

foreach ($dbName in $databases) {
    if ($systemDatabases -notcontains $dbName) {
        $backupFile = "$backupDir\backup_$dbName_$date.sql"  # Tệp sao lưu
        Write-Output "Starting backup for database: $dbName" | Out-File -FilePath $logFile -Append
        try {
            & "$mysqlDir\mysqldump.exe" -u $dbUser -p$dbPass $dbName > $backupFile
            Write-Output "Backup completed for database: $dbName" | Out-File -FilePath $logFile -Append
        } catch {
            Write-Output "Backup failed for database: $dbName - $_" | Out-File -FilePath $logFile -Append
        }

        # Nén tệp sao lưu
        $zipFile = "$backupDir\backup_$dbName_$date.zip"  # Tệp nén
        Write-Output "Starting compression for database: $dbName" | Out-File -FilePath $logFile -Append
        try {
            Compress-Archive -Path $backupFile -DestinationPath $zipFile
            Remove-Item $backupFile
            Write-Output "Compression completed for database: $dbName" | Out-File -FilePath $logFile -Append
        } catch {
            Write-Output "Compression failed for database: $dbName - $_" | Out-File -FilePath $logFile -Append
        }
    }
}

# Gửi email thông báo (tùy chọn)
Write-Output "Sending email: $(Get-Date)" | Out-File -FilePath $logFile -Append
try {
    $subject = "Database Backup Report"
    $body = "The backup process has completed. The backup files are attached."
    $message = New-Object system.net.mail.mailmessage
    $message.from = $emailFrom
    $message.To.Add($emailTo)
    $message.Subject = $subject
    $message.Body = $body
    $attachments = Get-ChildItem -Path $backupDir -Filter *.zip
    foreach ($attachment in $attachments) {
        $message.Attachments.Add($attachment.FullName)
    }
    $smtp = New-Object Net.Mail.SmtpClient($smtpServer, $smtpPort)
    $smtp.Credentials = New-Object System.Net.NetworkCredential($smtpUser, $smtpPass)
    $smtp.EnableSsl = $true
    $smtp.Send($message)
    Write-Output "Email sent successfully: $(Get-Date)" | Out-File -FilePath $logFile -Append
} catch {
    Write-Output "Email failed: $(Get-Date) - $_" | Out-File -FilePath $logFile -Append
}

# Xóa các bản sao lưu cũ hơn 7 ngày (tùy chọn)
Write-Output "Cleaning up old backups: $(Get-Date)" | Out-File -FilePath $logFile -Append
try {
    $daysToKeep = 7
    $files = Get-ChildItem -Path $backupDir -File | Where-Object { $_.CreationTime -lt (Get-Date).AddDays(-$daysToKeep) }
    foreach ($file in $files) {
        Remove-Item $file.FullName
        Write-Output "Deleted old backup file: $($file.FullName)" | Out-File -FilePath $logFile -Append
    }
    Write-Output "Cleanup completed successfully: $(Get-Date)" | Out-File -FilePath $logFile -Append
} catch {
    Write-Output "Cleanup failed: $(Get-Date) - $_" | Out-File -FilePath $logFile -Append
}
