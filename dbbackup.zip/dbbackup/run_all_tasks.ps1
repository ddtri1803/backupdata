# chạy : powershell.exe -File "run_all_tasks.ps1"
# Định nghĩa đường dẫn đến các tệp kịch bản
$backupScriptPath = "backup_all_databases.ps1"
$setupTaskScriptPath = "Setup-BackupTask.ps1"

# Chạy tệp kịch bản sao lưu
Write-Output "Starting database backup script: $(Get-Date)"
try {
    & "$backupScriptPath"
    Write-Output "Database backup script completed successfully: $(Get-Date)"
} catch {
    Write-Output "Database backup script failed: $(Get-Date) - $_"
    exit 1
}

# Chạy tệp kịch bản thiết lập tác vụ
Write-Output "Starting task setup script: $(Get-Date)"
try {
    & "$setupTaskScriptPath"
    Write-Output "Task setup script completed successfully: $(Get-Date)"
} catch {
    Write-Output "Task setup script failed: $(Get-Date) - $_"
    exit 1
}
